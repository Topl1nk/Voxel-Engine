import * as THREE from 'three';
import { WORLD_CONFIG, BLOCK } from './constants.js';
import { Chunk } from './chunk.js';
import { TextureGen } from './texture.js';

export class World {
    constructor(scene) {
        this.scene = scene;
        this.chunks = new Map();

        // ИЗМЕНЕНИЕ: Загружаем атлас вместо генерации
        const texture = TextureGen.loadAtlas();

        this.material = new THREE.MeshStandardMaterial({
            map: texture, // Сюда встанет картинка
            side: THREE.DoubleSide,
            alphaTest: 0.1,
            transparent: true,
            roughness: 1.0,
            metalness: 0.0,
            vertexColors: true
        });

        this.chunkCoordCache = new THREE.Vector2();
    }

    getChunkKey(cx, cz) {
        return cx + ":" + cz;
    }

    getCellFromPos(x, z) {
        this.chunkCoordCache.set(
            Math.floor(x / WORLD_CONFIG.CHUNK_SIZE),
            Math.floor(z / WORLD_CONFIG.CHUNK_SIZE)
        );
        return this.chunkCoordCache;
    }

    getBlock(x, y, z) {
        const cx = Math.floor(x / WORLD_CONFIG.CHUNK_SIZE);
        const cz = Math.floor(z / WORLD_CONFIG.CHUNK_SIZE);
        const key = this.getChunkKey(cx, cz);

        const chunk = this.chunks.get(key);
        if (!chunk) return BLOCK.AIR;

        const lx = x - cx * WORLD_CONFIG.CHUNK_SIZE;
        const lz = z - cz * WORLD_CONFIG.CHUNK_SIZE;
        return chunk.getBlock(lx, y, lz);
    }

    // Вспомогательный метод для регенерации конкретного чанка
    regenerateChunk(cx, cz) {
        const key = this.getChunkKey(cx, cz);
        const chunk = this.chunks.get(key);
        if (!chunk) return;

        // 1. Удаляем старый меш
        if (chunk.mesh) {
            this.scene.remove(chunk.mesh);
        }

        // 2. Генерируем новый (с учетом новых соседей)
        chunk.generateMesh();

        // 3. Добавляем в сцену
        if (chunk.mesh) {
            this.scene.add(chunk.mesh);
        }
    }

    setBlock(x, y, z, id) {
        const cx = Math.floor(x / WORLD_CONFIG.CHUNK_SIZE);
        const cz = Math.floor(z / WORLD_CONFIG.CHUNK_SIZE);
        const key = this.getChunkKey(cx, cz);

        const chunk = this.chunks.get(key);
        if (!chunk) return;

        const lx = x - cx * WORLD_CONFIG.CHUNK_SIZE;
        const lz = z - cz * WORLD_CONFIG.CHUNK_SIZE;

        // 1. Меняем данные в текущем чанке
        if (chunk.setBlock(lx, y, lz, id)) {

            // 2. Обновляем ТЕКУЩИЙ чанк
            this.regenerateChunk(cx, cz);

            // 3. Обновляем СОСЕДЕЙ, если блок на границе (радиус влияния AO = 1 блок)

            // Левый край -> Обновляем левого соседа
            if (lx === 0) this.regenerateChunk(cx - 1, cz);

            // Правый край -> Обновляем правого соседа
            if (lx === WORLD_CONFIG.CHUNK_SIZE - 1) this.regenerateChunk(cx + 1, cz);

            // Задний край -> Обновляем заднего соседа
            if (lz === 0) this.regenerateChunk(cx, cz - 1);

            // Передний край -> Обновляем переднего соседа
            if (lz === WORLD_CONFIG.CHUNK_SIZE - 1) this.regenerateChunk(cx, cz + 1);
        }
    }

    update(playerPos) {
        const pChunk = this.getCellFromPos(playerPos.x, playerPos.z);
        const px = pChunk.x;
        const pz = pChunk.y;
        const rd = WORLD_CONFIG.RENDER_DISTANCE;

        const validKeys = new Set();
        for (let x = px - rd; x <= px + rd; x++) {
            for (let z = pz - rd; z <= pz + rd; z++) {
                if ((x-px)*(x-px) + (z-pz)*(z-pz) <= rd*rd) {
                    validKeys.add(this.getChunkKey(x, z));
                }
            }
        }

        for (const [key, chunk] of this.chunks) {
            if (!validKeys.has(key)) {
                if(chunk.mesh) this.scene.remove(chunk.mesh);
                chunk.dispose();
                this.chunks.delete(key);
            }
        }

        let loaded = 0;
        for (const key of validKeys) {
            if (!this.chunks.has(key)) {
                const [cx, cz] = key.split(':').map(Number);

                // Передаем this (World), чтобы чанк мог видеть соседей
                const chunk = new Chunk(cx, cz, this.material, this);

                this.chunks.set(key, chunk);

                if (chunk.mesh) {
                    this.scene.add(chunk.mesh);
                }

                loaded++;
                if (loaded > 2) break;
            }
        }

        const el = document.getElementById('chunk-count');
        if(el) el.innerText = this.chunks.size;
    }
}
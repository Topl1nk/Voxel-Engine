import * as THREE from 'three';

export class Sky {
    constructor(scene) {
        // Создаем огромную сферу вокруг игрока
        const geometry = new THREE.SphereGeometry(500, 32, 32);

        // Шейдер для неба
        const material = new THREE.ShaderMaterial({
            uniforms: {
                uTime: { value: 0 },
                uSunPosition: { value: new THREE.Vector3() }
            },
            vertexShader: `
                varying vec3 vWorldPosition;
                void main() {
                    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
                    vWorldPosition = worldPosition.xyz;
                    gl_Position = projectionMatrix * viewMatrix * worldPosition;
                }
            `,
            fragmentShader: `
                uniform vec3 uSunPosition;
                uniform float uTime;
                varying vec3 vWorldPosition;

                // Функция шума для облаков
                float hash(vec3 p) {
                    p = fract(p * 0.3183099 + .1);
                    p *= 17.0;
                    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
                }

                float noise(vec3 x) {
                    vec3 i = floor(x);
                    vec3 f = fract(x);
                    f = f * f * (3.0 - 2.0 * f);
                    return mix(mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x),
                                   mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
                               mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
                                   mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
                }

                // Fractal Brownian Motion (слоистость облаков)
                float fbm(vec3 p) {
                    float v = 0.0;
                    float a = 0.5;
                    vec3 shift = vec3(100.0);
                    for (int i = 0; i < 5; ++i) {
                        v += a * noise(p);
                        p = p * 2.0 + shift;
                        a *= 0.5;
                    }
                    return v;
                }

                void main() {
                    vec3 direction = normalize(vWorldPosition);
                    vec3 sunDir = normalize(uSunPosition);

                    // 1. Градиент неба (голубой -> темно-синий)
                    float gradient = max(0.0, direction.y);
                    vec3 skyColor = mix(vec3(0.5, 0.7, 0.9), vec3(0.1, 0.3, 0.6), gradient);

                    // 2. Солнце (яркий круг)
                    float sun = dot(direction, sunDir);
                    float sunDisk = smoothstep(0.995, 0.998, sun);
                    skyColor += vec3(1.0, 0.9, 0.6) * sunDisk * 2.0;

                    // 3. Облака (шум)
                    // Двигаем облака по времени (uTime)
                    float cloudNoise = fbm(direction * 5.0 + vec3(uTime * 0.05, 0.0, uTime * 0.02));
                    // Делаем их только в верхней части неба
                    float cloudDensity = smoothstep(0.4, 0.7, cloudNoise) * smoothstep(0.0, 0.2, direction.y);

                    vec3 finalColor = mix(skyColor, vec3(1.0), cloudDensity * 0.8);

                    gl_FragColor = vec4(finalColor, 1.0);
                }
            `,
            side: THREE.BackSide // Рисуем на внутренней стороне сферы
        });

        this.mesh = new THREE.Mesh(geometry, material);
        scene.add(this.mesh);
    }

    update(playerPos, time) {
        this.mesh.position.copy(playerPos);
        this.mesh.material.uniforms.uTime.value = time;
    }

    setSunPosition(pos) {
        this.mesh.material.uniforms.uSunPosition.value.copy(pos);
    }
}
import * as THREE from 'three';
import { World } from './world.js';
import { Player } from './player.js';
import { Sky } from './sky.js';
import { WORLD_CONFIG } from './constants.js';
import { SoundManager } from './sound.js';

class Application {
    constructor() {
        // --- FIX: Объявляем переменные ДО инициализации сцены ---
        this.skyColor = new THREE.Color(0x87CEEB); // Голубое небо
        this.caveColor = new THREE.Color(0x050505); // Почти черный для пещер
        this.tempColor = new THREE.Color();
        this.clock = new THREE.Clock();
        this.isPaused = true;

        // Теперь можно инициализировать системы
        this.initRenderer();
        this.initScene();
        this.initWorld();

        this.setupEvents();
        this.animate();
    }

    initRenderer() {
        this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.body.appendChild(this.renderer.domElement);
    }

    initScene() {
        this.scene = new THREE.Scene();
        this.scene.background = this.skyColor.clone();

        const fogDist = WORLD_CONFIG.RENDER_DISTANCE * WORLD_CONFIG.CHUNK_SIZE;
        this.scene.fog = new THREE.Fog(this.skyColor, 20, fogDist - 10);

        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

        // 1. AMBIENT LIGHT
        this.ambient = new THREE.AmbientLight(0xffffff, 0.2);
        this.scene.add(this.ambient);

        // 2. HEMISPHERE LIGHT
        this.hemiLight = new THREE.HemisphereLight(0x87CEEB, 0x444444, 0.2);
        this.scene.add(this.hemiLight);

        // 3. SUN LIGHT
        this.sun = new THREE.DirectionalLight(0xffffff, 1.5);
        this.sun.position.set(50, 100, 50);
        this.sun.castShadow = true;

        // --- ТОНКАЯ НАСТРОЙКА ТЕНЕЙ ---
        const d = 50;
        this.sun.shadow.camera.left = -d;
        this.sun.shadow.camera.right = d;
        this.sun.shadow.camera.top = d;
        this.sun.shadow.camera.bottom = -d;

        this.sun.shadow.mapSize.width = 4096;
        this.sun.shadow.mapSize.height = 4096;

        // БАЛАНС:
        // bias: Убирает полоски на плоских поверхностях
        // normalBias: Убирает полоски на скруглениях (но у нас кубы)

        // Было: bias -0.0006, normalBias 0.05 (слишком много, тень отлетала)
        // Стало:
        this.sun.shadow.bias = -0.0001;      // Минимальный сдвиг
        this.sun.shadow.normalBias = 0.005;  // Очень маленький сдвиг по нормали, чтобы не отрывать угол

        this.scene.add(this.sun);
        this.scene.add(this.sun.target);

        // Инициализируем звук ПОСЛЕ создания камеры
        this.soundManager = new SoundManager(this.camera);
    }

    initWorld() {
        this.world = new World(this.scene);
        // Передаем soundManager игроку
        this.player = new Player(this.camera, this.renderer.domElement, this.world, this.soundManager);
        this.sky = new Sky(this.scene);
        this.world.update(this.player.position);
    }

    setupEvents() {
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });

        document.getElementById('start-btn')?.addEventListener('click', () => {
            this.renderer.domElement.requestPointerLock();
        });

        document.addEventListener('pointerlockchange', () => {
            this.isPaused = (document.pointerLockElement !== this.renderer.domElement);
            document.getElementById('menu-overlay').style.display = this.isPaused ? 'flex' : 'none';
        });
    }

    updateEnvironment() {
        // Защита от NaN, если физика игрока заглючит
        if (!this.player || !this.player.position) return;

        const y = this.player.position.y;

        // Интерполяция:
        // y > 40: Небо (factor = 1)
        // y < 10: Пещера (factor = 0)
        let factor = THREE.MathUtils.smoothstep(y, 10, 40);

        this.tempColor.lerpColors(this.caveColor, this.skyColor, factor);
        this.scene.background.copy(this.tempColor);

        if (this.scene.fog) {
            this.scene.fog.color.copy(this.tempColor);
        }

        // Динамическое освещение
        if (this.sun) this.sun.intensity = factor * 1.5;
        if (this.hemiLight) this.hemiLight.intensity = factor * 0.2;
        if (this.ambient) this.ambient.intensity = 0.05 + (0.1 * factor);
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const dt = Math.min(this.clock.getDelta(), 0.1);

        if (!this.isPaused) {
            this.player.update(dt);
            this.world.update(this.player.position);
            this.updateEnvironment();

            this.sun.position.set(
                this.player.position.x + 50,
                100,
                this.player.position.z + 50
            );
            this.sun.target.position.copy(this.player.position);
            this.sun.target.updateMatrixWorld();

            if (this.sky) this.sky.update(this.player.position, this.clock.elapsedTime);
        }

        this.renderer.render(this.scene, this.camera);

        const fpsEl = document.getElementById('fps-counter');
        if(fpsEl) fpsEl.innerText = Math.round(1/dt);
        const coordEl = document.getElementById('coords');
        if(coordEl) coordEl.innerText = `${Math.floor(this.player.position.x)}, ${Math.floor(this.player.position.y)}, ${Math.floor(this.player.position.z)}`;
    }
}

new Application();
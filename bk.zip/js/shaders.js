// SHADERS FIXED (Safe Lighting)
// Исправлена проблема, когда тени делали мир черным
export const VoxelShader = {
    vertex: `
        varying vec2 vUv;
        varying vec3 vNormal;
        varying vec3 vWorldPosition;
        varying float vDist;

        #include <common>
        #include <shadowmap_pars_vertex>

        void main() {
            vUv = uv;
            vNormal = normalize(normalMatrix * normal);

            vec4 worldPosition = modelMatrix * vec4(position, 1.0);
            vWorldPosition = worldPosition.xyz;

            vec4 mvPosition = viewMatrix * worldPosition;
            vDist = -mvPosition.z;

            gl_Position = projectionMatrix * mvPosition;

            #include <shadowmap_vertex>
        }
    `,

    fragment: `
        uniform sampler2D uMap;
        uniform vec3 uSunDir;
        uniform vec3 uFogColor;
        uniform float uFogNear;
        uniform float uFogFar;

        varying vec2 vUv;
        varying vec3 vNormal;
        varying float vDist;

        #include <common>
        #include <packing>
        #include <shadowmap_pars_fragment>

        void main() {
            vec4 texColor = texture2D(uMap, vUv);

            if(texColor.a < 0.5) discard;

            // РАСЧЕТ СВЕТА (SAFE MODE)
            // 1. Прямой свет от солнца
            float NdotL = max(0.0, dot(vNormal, uSunDir));
            float directLight = NdotL * 0.5; // Сила солнца

            // 2. Тени (от 0.0 до 1.0, где 0 - тень)
            float shadow = 1.0;
            #ifdef USE_SHADOWMAP
                shadow *= getShadowMask();
            #endif

            // 3. Фоновый свет (Ambient) - его НЕЛЬЗЯ умножать на тень!
            float ambientLight = 0.5;

            // Итоговый свет = (Солнце * Тень) + Фон
            // Это гарантирует, что даже в полной тени блоки видны на 50%
            float finalLight = ambientLight + (directLight * shadow);

            vec3 finalColor = texColor.rgb * finalLight;

            // Туман
            float fogFactor = smoothstep(uFogNear, uFogFar, vDist);
            gl_FragColor = vec4(mix(finalColor, uFogColor, fogFactor), 1.0);
        }
    `
};
import * as THREE from 'three';

export class TextureGen {
    static loadAtlas() { // Переименовали метод в loadAtlas
        const loader = new THREE.TextureLoader();

        // Укажите правильный путь к вашему файлу
        const texture = loader.load('./assets/atlas.png');

        // Настройки для Pixel Art (чтобы не было мыла)
        texture.magFilter = THREE.NearestFilter;
        texture.minFilter = THREE.NearestFilter;
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.anisotropy = 0;

        return texture;
    }
}